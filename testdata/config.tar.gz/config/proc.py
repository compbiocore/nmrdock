#!/usr/bin/env python

import yaml
import os

# Import PROC.YAML Dictionaries
with open(r'proc.yaml') as file:
    data = yaml.load(file, Loader=yaml.FullLoader)

# Parse Dimension Parameters from PROC.YAML
userinput = ''
for a in data['dimensions']:
    for i,j in data['dimensions'][a].items():
        if j:
            print(' -'+a + str(i) + ' ' + str(j))
            userinput = userinput+' -'+a + str(i) + ' ' + str(j)

# Execute BRUKER command to build FID.COM
if userinput:
    #With User Values from PROC.YAML
    os.system('bruker -auto -notk -user'+userinput)
else:
    #Without User Values from PROC.YAML
    os.system('bruker -auto -notk')
# Execute FID.COM
os.system('./fid.com')

# Parse Fourier Parameters from PROC.YAML
ftinput=''
noautoxp0 = False
for a in data['fourier']:
    for i,j in data['fourier'][a].items():
        if j:
            if a == 'x' and i == 'P0':
               noautoxp0 = True
            print(' -'+a + str(i) + ' ' + str(j))
            ftinput = ftinput+' -'+a + str(i) + ' ' + str(j)

# Execute BasicFT Command
#
# 2D Processing
if len(data['dimensions']) == 2:
    if ftinput:
        if noautoxp0:
            #With user input values and predetermined xP0
            os.system('basicFT2.com'+ftinput)
        else:
            #With user input values and xP0 set to Auto
            os.system('basicFT2.com -xP0 Auto'+ftinput)
    else:
        #With no user input values and xP0 set to Auto
        os.system('basicFT2.com -xP0 Auto')
# 3D Processing
if len(data['dimensions']) == 3:
    if ftinput:
        if noautoxp0:
            #With user input values and predetermined xP0
            os.system('basicFT3.com'+ftinput)
        else:
            #With user input values and xP0 set to Auto
            os.system('basicFT3.com -xP0 Auto'+ftinput)
    else:
        #With no user input values and xP0 set to Auto
        os.system('basicFT3.com -xP0 Auto')
